أرشيفي - مشروع أندرويد

هذا مجلد مشروع Android Studio (ليس ملف APK جاهزاً).

لإنشاء APK:
1) ثبّت Android Studio على كمبيوتر Windows/Mac/Linux.
2) افتح Android Studio واختر Open، ثم اختر مجلد Arshifi_Android_Project.
3) وافق على تثبيت Android SDK المطلوبة وانتظر Gradle Sync.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) بعد النجاح سيظهر زر Locate؛ ملف APK يكون عادة داخل app/build/outputs/apk/debug/app-debug.apk.
6) انقل APK إلى الهاتف وافتحه للتثبيت. قد يطلب Android السماح بالتثبيت من هذا المصدر.

مهم:
- التطبيق يعرض نسخة الويب داخل WebView ويحفظ بيانات الويب محلياً داخل بيانات التطبيق.
- استخدم النسخ الاحتياطي داخل البرنامج بانتظام، خاصة قبل تحديث التطبيق أو حذف بياناته.
- نسخة Windows لا تنتقل تلقائياً إلى الهاتف.
- هذا المشروع لم يُبنَ أو يُختبر على جهاز Android فعلي في بيئة الإنشاء الحالية.
